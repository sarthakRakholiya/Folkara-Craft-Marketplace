#!/bin/bash

# ============================================================
# AI Dev Workflow Skills Setup Script
# Run this from your PROJECT ROOT:
#   bash setup-ai-skills.sh
# ============================================================

set -e

echo ""
echo "🚀 Setting up AI Dev Workflow Skills..."
echo ""

# ── Directories ──────────────────────────────────────────────
mkdir -p .ai/commands
mkdir -p .ai/skills/fetch-ticket
mkdir -p .ai/skills/brainstorm
mkdir -p .ai/skills/write-plan
mkdir -p .ai/skills/execute-plan
mkdir -p .ai/skills/review
mkdir -p .ai/skills/check-edge-cases
mkdir -p .ai/skills/raise-pr
mkdir -p docs/ai-workflow
mkdir -p .vscode

echo "✅ Directories created"

# ── .ai/config.json ──────────────────────────────────────────
cat > .ai/config.json << 'EOF'
{
  "skills": {
    "paths": [".ai/skills"]
  },
  "commands": {
    "paths": [".ai/commands"]
  },
  "agent": {
    "instructions": "CLAUDE.md",
    "autoLoadSkills": true
  }
}
EOF
echo "✅ .ai/config.json"

# ── .cursorrules ─────────────────────────────────────────────
cat > .cursorrules << 'EOF'
# Cursor AI Rules — Dev Workflow

## Skills system
This project has a skills system. When working on any development task:
1. Check `.ai/skills/` for a relevant SKILL.md
2. Read it and follow it exactly
3. Skills are MANDATORY when they apply

## Slash commands
When the user types any of these, read and follow the corresponding file:

- `/dev` or `/dev JIRA-XXX` → read `.ai/commands/dev.md`
- `/brainstorm` → read `.ai/skills/brainstorm/SKILL.md`
- `/write-plan` → read `.ai/skills/write-plan/SKILL.md`
- `/execute` or `/execute-plan` → read `.ai/skills/execute-plan/SKILL.md`
- `/review` → read `.ai/skills/review/SKILL.md`
- `/check-edge-cases` or `/edge-cases` → read `.ai/skills/check-edge-cases/SKILL.md`
- `/raise-pr` → read `.ai/skills/raise-pr/SKILL.md`

## Critical rules
- Never start writing code without first checking for a skill
- Never execute a plan without explicit human "approve"
- Never raise a PR without running check-edge-cases and getting human "raise pr"
- Always save workflow artefacts to `docs/ai-workflow/`
- Read `CLAUDE.md` at the start of every session for project conventions

## Workflow sequence
fetch-ticket → brainstorm → write-plan → [HUMAN APPROVAL] → execute-plan → review → check-edge-cases → [HUMAN APPROVAL] → raise-pr
EOF
echo "✅ .cursorrules"

# ── .vscode/tasks.json ───────────────────────────────────────
cat > .vscode/tasks.json << 'EOF'
{
  "version": "2.0.0",
  "tasks": [
    {
      "label": "AI: Full Dev Workflow (/dev)",
      "type": "shell",
      "command": "echo 'Type /dev JIRA-123 in your AI assistant chat to start the workflow.'",
      "group": "none",
      "presentation": { "reveal": "always", "panel": "shared" }
    },
    {
      "label": "AI: Brainstorm task",
      "type": "shell",
      "command": "echo 'Type /brainstorm in your AI assistant chat.'",
      "group": "none"
    },
    {
      "label": "AI: Write implementation plan",
      "type": "shell",
      "command": "echo 'Type /write-plan in your AI assistant chat.'",
      "group": "none"
    },
    {
      "label": "AI: Execute plan",
      "type": "shell",
      "command": "echo 'Type /execute in your AI assistant chat.'",
      "group": "none"
    },
    {
      "label": "AI: Review implementation",
      "type": "shell",
      "command": "echo 'Type /review in your AI assistant chat.'",
      "group": "none"
    },
    {
      "label": "AI: Check edge cases",
      "type": "shell",
      "command": "echo 'Type /check-edge-cases in your AI assistant chat.'",
      "group": "none"
    },
    {
      "label": "AI: Raise PR",
      "type": "shell",
      "command": "echo 'Type /raise-pr in your AI assistant chat.'",
      "group": "none"
    }
  ]
}
EOF
echo "✅ .vscode/tasks.json"

# ── CLAUDE.md ────────────────────────────────────────────────
cat > CLAUDE.md << 'EOF'
# AI Agent Instructions — [Your Project Name]

## Skills system
This project uses a custom skills system. Before doing any development task,
you MUST check `.ai/skills/` for a relevant skill and follow it.

### How to find and use skills
- Skills live in `.ai/skills/[skill-name]/SKILL.md`
- Commands live in `.ai/commands/[command].md`
- Read the relevant SKILL.md and follow it exactly

### When a skill applies, you MUST use it. This is not optional.

---

## Available commands

### `/dev [JIRA-XXX]` — Full workflow
Runs the complete development pipeline:
fetch-ticket → brainstorm → write-plan → [HUMAN APPROVAL] → execute-plan → review → check-edge-cases → [HUMAN APPROVAL] → raise-pr

Read: `.ai/commands/dev.md`

---

## Available individual skills

| Skill | Trigger | File |
|-------|---------|------|
| fetch-ticket | Start of any task | `.ai/skills/fetch-ticket/SKILL.md` |
| brainstorm | Before designing anything | `.ai/skills/brainstorm/SKILL.md` |
| write-plan | After design approved | `.ai/skills/write-plan/SKILL.md` |
| execute-plan | After plan approved | `.ai/skills/execute-plan/SKILL.md` |
| review | After implementation | `.ai/skills/review/SKILL.md` |
| check-edge-cases | After review, before PR | `.ai/skills/check-edge-cases/SKILL.md` |
| raise-pr | After edge cases approved | `.ai/skills/raise-pr/SKILL.md` |

### Run a skill individually
Just say: `/brainstorm`, `/write-plan`, `/execute`, `/review`, `/check-edge-cases`, `/raise-pr`

---

## Ground rules
1. Never write code without a plan.
2. Never execute a plan without human approval.
3. Never commit to main directly.
4. Never skip the review skill.
5. Never raise a PR without running check-edge-cases and getting human approval.
6. Always save artefacts to `docs/ai-workflow/`.

---

## Project conventions
- Framework: [React / Next.js / Vue — fill in]
- Styling: [Tailwind / CSS Modules — fill in]
- Testing: [Jest / Vitest / Playwright — fill in]
- Package manager: [npm / pnpm / yarn — fill in]
- Lint command: npm run lint
- Test command: npm test
- Dev server: npm run dev

---

## JIRA config
- JIRA base URL: [https://yourcompany.atlassian.net — fill in]
- Project key: [PROJ — fill in]
- MCP: If JIRA MCP is connected, use it. Otherwise prompt for manual input.
EOF
echo "✅ CLAUDE.md"

# Symlink for non-Claude agents
ln -sf CLAUDE.md AGENTS.md 2>/dev/null || cp CLAUDE.md AGENTS.md
echo "✅ AGENTS.md"

# ── .ai/commands/dev.md ──────────────────────────────────────
cat > .ai/commands/dev.md << 'EOF'
# /dev — Global Developer Workflow Command

## What this command does
Master orchestrator for the full dev workflow.
Accepts a JIRA ticket number OR prompts for task info, then chains all skills
in order with human approval gates.

## Trigger
User types: `/dev` or `/dev JIRA-123` or `/dev` (no args)

## Orchestration Steps

### Step 1 — Ticket intake
Invoke skill: fetch-ticket
Save task spec to `docs/ai-workflow/current-task.md`

### Step 2 — Brainstorm
Invoke skill: brainstorm
Present analysis in sections. Ask: "Does this look correct before planning?"
Wait for approval or adjustments.

### Step 3 — Write Plan
Invoke skill: write-plan
Present the full plan to the human.

### Step 4 — HUMAN APPROVAL GATE ⛔
STOP. Display:
---
✅ Plan is ready. Please review above.
Type `approve` to begin execution, or give feedback to revise.
---
Wait for explicit `approve`. If feedback given, revise and repeat gate.

### Step 5 — Execute Plan
Invoke skill: execute-plan
Execute tasks one by one with verification after each.

### Step 6 — Review
Invoke skill: review
Present findings. Fix any issues found.

### Step 7 — Check edge cases
Invoke skill: check-edge-cases
Check all edge case categories. Fix every ❌ blocking finding.
Present the full report to the human.

### Step 8 — HUMAN APPROVAL GATE ⛔ (PR gate)
STOP. The check-edge-cases skill displays the approval prompt.
Wait for explicit `raise pr`.
If human asks to investigate further, do so and re-present.

### Step 9 — Raise PR
Invoke skill: raise-pr
Include edge case findings in PR body.
Announce the PR link.

## Notes
- Each skill CAN be run independently
- Save all artefacts to `docs/ai-workflow/`
- TWO human approval gates: plan (Step 4) and PR (Step 8)
- Never skip either gate
EOF
echo "✅ .ai/commands/dev.md"

# ── fetch-ticket ─────────────────────────────────────────────
cat > .ai/skills/fetch-ticket/SKILL.md << 'EOF'
# Skill: fetch-ticket

## Purpose
Gather task information from ANY starting point — JIRA ticket, full description,
one-liner, or nothing — and produce a structured task spec.
Never block the user. Always find a path forward.

## When to use
- At the start of any `/dev` workflow
- Run independently with: `/fetch-ticket`

## Instructions

Detect which situation applies:

### Situation A — JIRA ticket number provided (e.g. `/dev PROJ-123`)
1. Fetch from JIRA via MCP or API (check `.ai/config.json` for base URL).
   Fetch: summary, description, acceptance criteria, story points, labels.
2. If fetch succeeds → go to [Build spec].
3. If fetch fails → say: "Couldn't reach JIRA for PROJ-123. Tell me what the task is about."
   Then follow Situation B or C.

### Situation B — Full description provided (a paragraph or more)
Extract title, problem, expected outcome. Infer acceptance criteria.
Go to [Build spec], mark inferred fields with `[inferred]`.
Ask: "I've drafted the spec — does this look right?"

### Situation C — Vague one-liner (e.g. "add dark mode" / "fix login bug")
Run a short interview — ONE question at a time, max 4 questions:
1. "What should work after this is done that doesn't work now?"
2. "Which area does this touch — frontend, backend, a specific page?"
3. "Anything I should know — edge cases, design decisions already made?"
4. "How will you know it's complete?"
Stop as soon as you have enough. Mark remaining fields as `[assumed]`.

### Situation D — Nothing provided
Say: "What are we building or fixing today? Even a rough idea works."
Wait, then route to B or C.

### [Build spec]
Save to: `docs/ai-workflow/current-task.md`

```
# Task: [TITLE]
**Ticket:** [PROJ-123 | Manual | No ticket]
**Date:** [today]
**Input type:** [JIRA fetched | Full description | Interview | Assumed]

## Summary
[1-2 sentences]

## Problem
[What's broken, missing, or needed]

## Acceptance Criteria
- [ ] [criterion — mark [inferred] or [assumed] if not stated]

## Scope hints
[Frontend / Backend / Full-stack — any specific files/areas mentioned]

## Open questions
[Anything still unclear that brainstorm should investigate]
```

Show spec to user and ask: "Does this capture what you need?"
Save file and announce: "Task spec saved to docs/ai-workflow/current-task.md ✓"

## Notes
- Never say "I need more information before I can help." Always make progress.
- Inferred/assumed fields are fine — brainstorm will validate against the codebase.
- For frontend: note if it's a component, page, or data flow change.
- For full-stack: note both surfaces even if user only mentioned one.
EOF
echo "✅ .ai/skills/fetch-ticket/SKILL.md"

# ── brainstorm ───────────────────────────────────────────────
cat > .ai/skills/brainstorm/SKILL.md << 'EOF'
# Skill: brainstorm

## Purpose
Deep code-level analysis of the task before writing any code.
Explore approaches, identify risks, define the design, save a design document.

## When to use
- After fetch-ticket produces a task spec
- Run independently with: `/brainstorm`
- Before any planning or coding

## Announcement
"I'm using the brainstorm skill to analyse this task at code level."

## Instructions

### Step 1 — Read context
- Read `docs/ai-workflow/current-task.md`
- Scan codebase: top-level dirs, key config files, existing patterns
- Identify relevant existing files that will need to change

### Step 2 — Present analysis in sections

**Section A: Current state**
- What exists in the codebase related to this task
- Which files are affected
- Patterns already in use (component libraries, state management, API patterns)

**Section B: Approach options** (2-3 alternatives)
For each: what it does, pros/cons, estimated complexity (S/M/L), recommended? why?

**Section C: Recommended design**
- Chosen approach with justification
- New files to create (with purpose)
- Existing files to modify (what changes)
- Data flow / state changes
- API contracts (if full-stack)
- Edge cases and handling

**Section D: Risks & dependencies**
- Things that could go wrong
- External dependencies
- Testing considerations

### Step 3 — Ask for validation
After each section: "Does section [X] look right? Any changes?"

### Step 4 — Save design document
Save to: `docs/ai-workflow/design-[TICKET]-[YYYY-MM-DD].md`

## Notes
- Frontend: focus on component boundaries, prop/state shape, accessibility
- Backend: focus on DB schema, API contract, auth requirements
- Never write actual code in this skill — design only
EOF
echo "✅ .ai/skills/brainstorm/SKILL.md"

# ── write-plan ───────────────────────────────────────────────
cat > .ai/skills/write-plan/SKILL.md << 'EOF'
# Skill: write-plan

## Purpose
Turn the approved design into a granular, executable implementation plan.
Each task must be small enough to implement in isolation and verify.

## When to use
- After brainstorm design is approved
- Run independently with: `/write-plan`

## Announcement
"I'm using the write-plan skill to create the implementation plan."

## Prerequisites
- `docs/ai-workflow/design-*.md` exists and is approved
- If not found, invoke brainstorm skill first

## Instructions

### Step 1 — Map all files
List every file that will be created, modified, or deleted.
Each file gets one clear responsibility. If a file does two things, split tasks.

### Step 2 — Break into tasks
Each task must:
- Take 2-10 minutes to implement
- Have a single, clear outcome
- Include exact file paths
- Include enough context that no prior knowledge is needed
- Have a verification step

Tasks ordered so each builds on the previous.

### Step 3 — Write the plan
Save to: `docs/ai-workflow/plan-[TICKET]-[YYYY-MM-DD].md`

```
# Implementation Plan: [Task Title]
> For AI execution: Use skill execute-plan to implement task-by-task.

**Ticket:** [ref]  **Design doc:** [link]  **Date:** [date]

## Files map
| File | Action |
|------|--------|
| src/... | Create |
| src/... | Modify |

## Tasks

### Task 1 — [Short title]
**File:** `src/components/Foo.tsx`
**What:** [exactly what to do]
**Code guidance:** [specific implementation notes]
**Verify:** [command or check to confirm it works]
- [ ] Task complete

### Task 2 — ...
```

### Step 4 — Present plan and STOP
Show plan. Ask:
> "Plan ready. Type `approve` when ready to execute, or give feedback to adjust."

STOP. Do not begin execution. Wait for explicit approval.

## Notes
- Max 15 tasks per plan. If more, split into phases.
- Frontend: include component name, props, state, event handlers
- Backend: include route, request/response shape, DB changes
- Include rollback note for DB migrations
EOF
echo "✅ .ai/skills/write-plan/SKILL.md"

# ── execute-plan ─────────────────────────────────────────────
cat > .ai/skills/execute-plan/SKILL.md << 'EOF'
# Skill: execute-plan

## Purpose
Implement an approved plan, task by task, with verification after each step.
Never skip tasks. Never invent tasks not in the plan.

## When to use
- ONLY after explicit human approval of the plan
- Run independently with: `/execute`

## Announcement
"Executing plan. I will complete each task and verify before moving on."

## Prerequisites
- `docs/ai-workflow/plan-*.md` exists
- Human has typed `approve`
- If plan not approved, STOP and return to write-plan

## Instructions

### Before starting
Read the full plan. Note the files map. Understand all tasks before beginning.

### For each task

1. **Announce:** "Working on Task N: [title]"

2. **Implement**
   - Follow code guidance exactly
   - Do not add extra features
   - Do not refactor things not mentioned in the plan
   - Match existing code style

3. **Verify**
   - Run the verification command from the plan
   - If fails: fix, re-run, do not move on until passing
   - If cannot fix: pause and report to human with details

4. **Mark complete**
   - Update checkbox in plan: `- [x] Task complete`
   - Report: "Task N complete ✓"

5. **Pause if blocked**
   If unexpected: STOP, report exactly what was found, ask for guidance.

### After all tasks
- Run full test suite: `npm test`
- Run linter: `npm run lint`
- Fix any failures
- Report: "All tasks complete. Tests passing. Ready for review."

## Notes
- One task at a time. Never batch.
- Do not commit during execution — commit happens in raise-pr
- Warn human before running DB migrations
EOF
echo "✅ .ai/skills/execute-plan/SKILL.md"

# ── review ───────────────────────────────────────────────────
cat > .ai/skills/review/SKILL.md << 'EOF'
# Skill: review

## Purpose
Two-stage review: spec compliance first, then code quality.

## When to use
- After execute-plan completes
- Run independently with: `/review`

## Announcement
"Running two-stage review: spec compliance then code quality."

## Stage 1 — Spec compliance

Check each acceptance criterion from `docs/ai-workflow/current-task.md`:
- Is it implemented?
- Is it tested?
- Does it match the spec exactly — not more, not less?

Check each task in the plan:
- Is the checkbox marked complete?
- Does actual code match the task description?
- Were any extra files created beyond the plan?

Result: if all pass → Stage 2. If any fail → list what's wrong, fix, re-run.

## Stage 2 — Code quality (only after Stage 1 passes)

### Correctness
- No obvious logic errors
- Edge cases handled (null, empty, error states)
- No hardcoded values that should be config/env vars

### Security
- No SQL injection risks
- No exposed secrets or API keys
- Auth checks on new API routes

### Maintainability
- Functions do one thing
- Clear naming (no temp, foo, data2)
- No deeply nested logic (max 3 levels)
- Complex logic has a WHY comment

### Frontend
- Accessible (ARIA, keyboard navigation)
- No inline styles that should be CSS/Tailwind
- Loading, empty, error states handled
- No console.log left in

### Performance
- No N+1 queries
- No unnecessary re-renders

### Output
Save to: `docs/ai-workflow/review-[DATE].md`

Fix all issues before marking review complete.

## Notes
- Strict in Stage 1. Don't move on if anything is missing.
- Mark non-blockers as `[suggestion]`
EOF
echo "✅ .ai/skills/review/SKILL.md"

# ── check-edge-cases ─────────────────────────────────────────
cat > .ai/skills/check-edge-cases/SKILL.md << 'EOF'
# Skill: check-edge-cases

## Purpose
Before raising a PR, systematically identify and verify edge cases.
BLOCKING step — no PR raised until this passes and human approves.

## When to use
- After review passes, before raise-pr
- Run independently with: `/check-edge-cases`

## Announcement
"Running edge case analysis before raising the PR."

## Instructions

### Step 1 — Read context
- Read `docs/ai-workflow/current-task.md`
- Read `docs/ai-workflow/plan-*.md`
- Read `docs/ai-workflow/review-*.md`
- Scan changed files: `git diff --name-only`

### Step 2 — Check each category

#### A. Input & data
- Empty / null / undefined inputs
- Whitespace-only strings
- Extremely long inputs (UI truncate? DB column fit?)
- Special characters (quotes, ampersands, emojis, unicode)
- Zero / negative numbers
- Boundary values (min/max)

#### B. State & async
- Double-submit (user clicks twice quickly)
- Slow network — loading state shown?
- Network failure — error state and retry?
- Component unmounts mid-request (memory leak?)
- Race conditions (two requests in flight)

#### C. Auth & permissions
- Logged-out user hits feature directly via URL
- Insufficient permissions user calls API directly
- Token expires mid-session
- Resource ownership (user A access user B's data?)

#### D. Data integrity
- DB record deleted between read and write
- Unique constraint violations possible?
- Concurrent edit conflict
- Orphaned child records on delete

#### E. UI / frontend
- Zero items (empty state)
- 1 item vs 100 items
- Long text overflow/truncation
- Mobile viewport (320px)
- Images fail to load

#### F. Integration & environment
- Feature flags OFF
- Third-party service error or timeout
- Dev vs prod environment configs

### Step 3 — Classify each finding
- ✅ Handled — tested and working
- ⚠️ Partially handled — non-blocking suggestion
- ❌ Not handled — MUST fix before PR
- N/A — not applicable

### Step 4 — Fix all ❌ findings
Implement fix → verify → update to ✅. Do not move on until all ❌ resolved.

### Step 5 — Save report
Save to: `docs/ai-workflow/edge-cases-[TICKET]-[DATE].md`

```
# Edge Case Report: [Task Title]
**Ticket:** [ref]  **Date:** [date]

## Summary
[N] cases checked. [N] handled. [N] fixed. [N] suggestions.

## Results

### A. Input & data
| Case | Status | Notes |
|------|--------|-------|
| Empty name field | ✅ Handled | Zod required() |
| 500-char name | ❌ Fixed | Added maxLength(100) |

### [suggestions]
- Consider optimistic UI for the save action
```

### Step 6 — HUMAN APPROVAL GATE ⛔

STOP. Display:

```
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
🔍 Edge case check complete.

  ✅ X cases handled
  🔧 X cases fixed
  ⚠️  X suggestions (non-blocking)

All blockers resolved. Ready to raise PR.
Type `raise pr` to proceed.
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
```

Wait for explicit `raise pr`. If human asks to investigate further, do so and re-present.

## Notes
- ⚠️ suggestions go in PR as "Future improvements" — do NOT block PR
- If a ❌ fix adds scope, flag to human before implementing
- This checks behaviour, not code style (style was in review)
EOF
echo "✅ .ai/skills/check-edge-cases/SKILL.md"

# ── raise-pr ─────────────────────────────────────────────────
cat > .ai/skills/raise-pr/SKILL.md << 'EOF'
# Skill: raise-pr

## Purpose
Create a well-named branch, commit all changes, and raise a PR.

## When to use
- After check-edge-cases passes and human types `raise pr`
- Run independently with: `/raise-pr`

## Announcement
"Raising PR. Edge cases already approved — committing and pushing now."

## Prerequisites
- check-edge-cases skill has run and human typed `raise pr`
- If edge case check NOT done, STOP and invoke check-edge-cases first

## Instructions

### Step 1 — Check git status
```bash
git status
git diff --stat
```
Confirm all expected files are modified/added. Report unexpected changes.

### Step 2 — Create branch
- Feature: `feat/JIRA-123-short-description`
- Bug fix: `fix/JIRA-123-short-description`
- Chore: `chore/JIRA-123-short-description`
Kebab-case. Max 50 chars.

### Step 3 — Stage and commit
```bash
git add -A
git commit -m "type(TICKET): short summary

- what changed
- why it was needed
- fixes/closes reference"
```
Types: `feat`, `fix`, `chore`, `refactor`, `test`, `docs`

### Step 4 — Push
```bash
git push origin HEAD
```

### Step 5 — Raise PR
```bash
gh pr create \
  --title "type(TICKET): summary" \
  --body "$(cat docs/ai-workflow/pr-body.md)" \
  --base main \
  --draft
```

Save PR body to `docs/ai-workflow/pr-body.md`:
```
## Summary
[1-2 sentences from task spec]

## Changes
- [what was added/changed]

## Edge cases verified
[Pull ✅ rows from edge-cases report]
- Empty input: handled via Zod required()
- Double-submit: button disabled on loading
- Auth check: 401 for unauthenticated requests

## Testing
- [ ] Unit tests pass (npm test)
- [ ] Linter passes (npm run lint)
- [ ] Manually tested: [describe]

## Screenshots
[Add if UI changes]

## Future improvements
[⚠️ suggestions from edge case report]

## JIRA
Closes JIRA-123
```

### Step 6 — Report
Print PR URL.
> "PR raised as DRAFT. Add screenshots if needed, then mark ready for review."

## Notes
- Always raise as DRAFT — human marks ready for review
- If `gh` not installed, output git commands for human to run
- Never force push to main/master
- If branch exists, ask before overwriting
EOF
echo "✅ .ai/skills/raise-pr/SKILL.md"

# ── docs/ai-workflow/README.md ───────────────────────────────
cat > docs/ai-workflow/README.md << 'EOF'
# AI Workflow Artefacts

This folder contains runtime artefacts generated by the AI dev workflow.

| File pattern | Generated by |
|---|---|
| `current-task.md` | fetch-ticket skill |
| `design-[TICKET]-[DATE].md` | brainstorm skill |
| `plan-[TICKET]-[DATE].md` | write-plan skill |
| `review-[DATE].md` | review skill |
| `edge-cases-[TICKET]-[DATE].md` | check-edge-cases skill |
| `pr-body.md` | raise-pr skill |

These files are committed so the whole team can see AI reasoning and decisions.
EOF
echo "✅ docs/ai-workflow/README.md"

# ── Done ─────────────────────────────────────────────────────
echo ""
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "✅ All done! Structure created:"
echo ""
find .ai docs/ai-workflow CLAUDE.md AGENTS.md .cursorrules -type f | sort | sed 's/^/   /'
echo ""
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo ""
echo "Next steps:"
echo "  1. Edit CLAUDE.md — fill in your framework, test/lint commands, JIRA URL"
echo "  2. Commit everything:  git add .ai CLAUDE.md AGENTS.md .cursorrules .vscode docs"
echo "  3. In your AI tool, type:  /dev JIRA-123  (or just /dev)"
echo ""
