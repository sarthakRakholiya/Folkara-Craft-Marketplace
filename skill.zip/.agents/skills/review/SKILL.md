---
name: review
description: Two-stage review: spec compliance and code quality.
---

# Skill: review

## Purpose

Two-stage review: spec compliance first, then code quality.

## When to use

- After execute-plan completes
- Run independently with: `/review`

## Announcement

"Running two-stage review: spec compliance then code quality."

## Stage 1 — Spec compliance

Check each acceptance criterion from `docs/ai-workflow/current-task.md`:

- Is it implemented?
- Is it tested?
- Does it match the spec exactly — not more, not less?

Check each task in the plan:

- Is the checkbox marked complete?
- Does actual code match the task description?
- Were any extra files created beyond the plan?

Result: if all pass → Stage 2. If any fail → list what's wrong, fix, re-run.

## Stage 2 — Code quality (only after Stage 1 passes)

### Correctness

- No obvious logic errors
- Edge cases handled (null, empty, error states)
- No hardcoded values that should be config/env vars

### Security

- No SQL injection risks
- No exposed secrets or API keys
- Auth checks on new API routes

### Maintainability

- Functions do one thing
- Clear naming (no temp, foo, data2)
- No deeply nested logic (max 3 levels)
- Complex logic has a WHY comment

### Frontend

- Accessible (ARIA, keyboard navigation)
- No inline styles that should be CSS/Tailwind
- Loading, empty, error states handled
- No console.log left in

### Performance

- No N+1 queries
- No unnecessary re-renders

### Output

Save to: `docs/ai-workflow/review-[DATE].md`

Fix all issues before marking review complete.

## Notes

- Strict in Stage 1. Don't move on if anything is missing.
- Mark non-blockers as `[suggestion]`
