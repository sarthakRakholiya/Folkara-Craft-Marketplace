---
name: brainstorm
description: Deep code-level analysis of the task before writing any code. Explore approaches, identify risks, define the design, save a design document.
---

# Skill: brainstorm

## Purpose

Deep code-level analysis of the task before writing any code.
Explore approaches, identify risks, define the design, save a design document.

## When to use

- After fetch-ticket produces a task spec
- Run independently with: `/brainstorm`
- Before any planning or coding

## Announcement

"I'm using the brainstorm skill to analyse this task at code level."

## Instructions

### Step 1 — Read context

- Read `docs/ai-workflow/current-task.md`
- Scan codebase: top-level dirs, key config files, existing patterns
- Identify relevant existing files that will need to change

### Step 2 — Present analysis in sections

**Section A: Current state**

- What exists in the codebase related to this task
- Which files are affected
- Patterns already in use (component libraries, state management, API patterns)

**Section B: Approach options** (2-3 alternatives)
For each: what it does, pros/cons, estimated complexity (S/M/L), recommended? why?

**Section C: Recommended design**

- Chosen approach with justification
- New files to create (with purpose)
- Existing files to modify (what changes)
- Data flow / state changes
- API contracts (if full-stack)
- Edge cases and handling

**Section D: Risks & dependencies**

- Things that could go wrong
- External dependencies
- Testing considerations

### Step 3 — Ask for validation

After each section: "Does section [X] look right? Any changes?"

### Step 4 — Save design document

Save to: `docs/ai-workflow/design-[TICKET]-[YYYY-MM-DD].md`

## Notes

- Frontend: focus on component boundaries, prop/state shape, accessibility
- Backend: focus on DB schema, API contract, auth requirements
- Never write actual code in this skill — design only
