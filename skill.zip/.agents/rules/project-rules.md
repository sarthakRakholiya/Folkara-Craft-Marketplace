---
trigger: always_on
---

# Next.js Enterprise Architecture Guide

> **Stack:** Next.js (App Router) · TypeScript · Tailwind CSS · React Hook Form · Zod · Prisma · Neon PostgreSQL · Clerk · UploadThing · Stripe Connect · Vercel AI SDK

---

## 1. Principles

Every module must be scalable, modular, typed, reusable, accessible, secure, performant, and maintainable. Favour server-side execution, feature isolation, and explicit typing over convenience shortcuts.

---

## 2. Project Structure

```
src/
├── app/                    # App Router (routes only — no logic)
│   ├── (public)/           # Unauthenticated routes
│   ├── (auth)/             # Login / signup flows
│   ├── (dashboard)/        # Authenticated dashboard routes
│   ├── api/                # Route handlers (thin wrappers)
│   └── layout.tsx
├── features/               # Domain modules (see §4)
├── components/             # Shared UI (ui/, form/, layout/, shared/, feedback/)
├── actions/                # Server Actions
├── services/               # Business logic & third-party calls
├── hooks/                  # Shared hooks (use* prefix)
├── providers/              # Context providers
├── lib/                    # Pure utilities (date, format, etc.)
├── config/                 # App & theme configuration
├── styles/                 # globals.css, font imports
├── types/                  # Shared TypeScript types
├── constants/              # Routes, roles, regex, limits
├── validations/            # Zod schemas
├── prisma/                 # Schema, migrations, seed
└── middleware.ts           # Auth, redirects, locale, RBAC
```

---

## 3. Routing & Pages

Pages are thin entry points — import a feature view, render it, nothing else.

```tsx
// ✗ Bad — logic inside page
export default function Page() {
  const data = await fetchSomething();
  return <div>{/* ... */}</div>;
}

// ✓ Good — delegate to feature layer
import { DashboardView } from "@/features/dashboard/views/dashboard-view";
export default function Page() {
  return <DashboardView />;
}
```

Every async route must include sibling `loading.tsx` and `error.tsx`.

---

## 4. Feature Modules

Each domain is self-contained under `features/<name>/` and removable without breaking unrelated code.

```
features/product/
├── actions/           # Feature-scoped server actions
├── api/               # Feature-scoped route helpers
├── components/        # Feature-specific UI components
├── loader/            # Data-fetching / RSC loaders
├── modals/            # Feature-specific dialogs and modals
├── hooks/             # Feature-specific hooks
├── services/          # Business logic & external calls
├── schemas/           # Zod schemas (feature-level)
├── types/             # Feature types
├── views/             # Page-level compositions
├── utils.ts           # Feature-specific helpers
└── README.md          # Feature docs (required)
```

> Every feature must contain its own `components/`, `loader/`, `modals/`, and `utils.ts`.

---

## 5. Component Guidelines

- Default to **Server Components**. Add `"use client"` only for `useState`, `useEffect`, browser APIs, or animations.
- Always use **named exports** (default exports only for Next.js pages/layouts).
- **1 component per file**, max ~300 lines. Extract reusable logic into hooks.
- `components/ui/` — stateless primitives only (button, card, dialog, table, badge, tooltip, tabs).
- All components must support keyboard navigation, `aria-*` attributes, focus states, and screen readers.

---

## 6. Forms & Validation

**Stack:** React Hook Form + Zod + `@hookform/resolvers/zod`

Each form control (`components/form/`) wraps `Controller` internally. Consumer passes only `control`, `name`, `label`, `placeholder`. Every control must handle labels, validation messages, required/disabled/loading states, dark mode, and accessibility.

```tsx
<FormInput control={form.control} name="email" label="Email" placeholder="Enter email" />
```

All schemas in `validations/<domain>.validation.ts`:

```ts
export const loginSchema = z.object({ email: z.string().email(), password: z.string().min(8) });
export type LoginSchema = z.infer<typeof loginSchema>;
```

Every submission must show loading state, disable the button, and apply optimistic updates where appropriate.

---

## 7. Styling & Theming

- No arbitrary hex (`bg-primary` not `bg-[#1a1a2e]`), no arbitrary spacing (`mt-4` not `mt-[13px]`).
- Mobile-first responsive design.
- All tokens centralised in `config/theme/` and `globals.css` via CSS custom properties.

```css
:root { --primary: 222 47% 11%; --radius: 0.5rem; }
```

**Semantic palette:** `primary`, `secondary`, `accent`, `muted`, `success`, `warning`, `danger`, `background`, `foreground`, `card`, `border`, `input`, `ring` — each with `DEFAULT` + `foreground` variants via `hsl(var(--token))`.

**Breakpoints:** `xs: 480px`, `sm: 640px`, `md: 768px`, `lg: 1024px`, `xl: 1280px`, `2xl: 1536px`.

Use Framer Motion sparingly — only when it serves usability.

---

## 8. Data Layer

```
Client ──► Server Action ──► Service ──► Prisma ──► Neon (PostgreSQL)
```

| Layer | Location | Responsibility |
|---|---|---|
| Service | `services/` | Business logic, Prisma queries, external APIs, AI, Stripe |
| Server Action | `actions/` | Validate → auth → call service → standardised response |

**Prisma:** Singleton client in `lib/prisma.ts`. Every model includes `id`, `createdAt`, `updatedAt`. Models in `PascalCase`, fields in `camelCase`. Use proper indexes. Neon PostgreSQL with `pgvector`. Never expose DB to client.

**Fetching priority:** Server Components → Server Actions → Client-side (last resort).

**Caching:** `revalidateTag`, `unstable_cache`, cursor-based pagination for large datasets.

---

## 9. Auth & Authorization

**Provider:** Clerk. Roles (`ADMIN`, `BUYER`, `SELLER`) stored in session claims.

**Protection checklist:** Server actions, API routes, pages, layouts, and middleware must all verify auth + role before executing.

---

## 10. API & Server Actions

Route handlers (`app/api/`) are thin wrappers — no business logic. Server actions follow this pattern:

```ts
export async function createProductAction(input: unknown) {
  const parsed = schema.safeParse(input);         // 1. Validate
  if (!parsed.success) return { success: false, error: parsed.error.flatten() };
  const user = await currentUser();                // 2. Authenticate
  if (!user) return { success: false, error: "Unauthorized" };
  authorizeRole(user, ["SELLER", "ADMIN"]);        // 3. Authorize
  const product = await productService.create(parsed.data, user.id); // 4. Execute
  return { success: true, data: product };         // 5. Respond
}
```

**Response envelope:** `{ success: true, data, message? }` or `{ success: false, error }`.

---

## 11. File Uploads

**Provider:** UploadThing. Organise by domain: `uploads/products/`, `uploads/avatars/`, `uploads/documents/`.

---

## 12. AI Integration

**SDK:** Vercel AI SDK. **Models:** Gemini 2.5 Flash (generation), `text-embedding-004` (embeddings).

All AI code in `features/ai/` with separate modules for prompts, embeddings, chat, streaming, and generation. Semantic search via `pgvector` + cosine similarity with embedding caching.

---

## 13. Payments

**Provider:** Stripe Connect in `services/stripe/`. Never trust client-side prices — server must validate payment amount, user identity, seller account, and platform fee.

---

## 14. State Management

Prefer in order: Server state → URL state → React state → Zustand (only when truly global).

---

## 15. Error Handling & UX States

Every list/table handles four states: loading (skeleton), empty (illustration + CTA), error (retry + message), success (data). Use a single centralised toast system.

---

## 16. Performance & SEO

- Use `next/dynamic` for heavy client components, `next/image` exclusively (never raw `<img>`).
- `metadata` API for SEO (never `next/head`).
- Apply memoisation only when profiling justifies it.

---

## 17. Security

Validate and sanitise every server input. Never expose secrets — use `.env.local` for dev, platform secrets for production. All sensitive operations require server-side auth regardless of client guards.

---

## 18. Testing

**Unit/integration:** Vitest + React Testing Library. **E2E:** Playwright.

---

## 19. Code Quality & Git

**Tooling:** ESLint, Prettier, Husky, lint-staged.

| Target | Convention | Example |
|---|---|---|
| Files | `kebab-case` | `product-card.tsx` |
| Components | `PascalCase` | `ProductCard` |
| Variables | `camelCase` | `getProductById` |
| Hooks | `use` prefix | `useProductFilters` |

Always use `@/` alias — relative traversals prohibited. Centralised logger only — no `console.log` in production.

**Branches:** `feature/`, `fix/`, `refactor/`, `hotfix/`. **Commits:** `feat:`, `fix:`, `refactor:`, `docs:`, `test:`.

---

## 20. Deployment

**Platform:** Vercel. Env vars per-environment, preview deploys on PRs, production builds must pass lint + type-check + tests before merge.


Dont read .env files 

